# Proposed standard

## Name

**CRAFT Standard**
**Credibility, Rigor, Assumption, Falsifiability, and Terminology**

And the proprietary composite score:

**BASS Score**
**Bayesian Audit of Scientific Substance**

That gives you:

* **CRAFT** = the review framework
* **BASS** = the normalized composite score

A paper gets:

* a **CRAFT profile**
* a **BASS score**
* uncertainty / confidence metascores
* a short diagnostic verdict

---

# First: define what counts as a claim

This is the load-bearing piece. If claim counting is mushy, the whole thing turns into swamp soup.

## Claim ontology

A **claim** is any proposition the paper asks the reader to accept as true, plausible, derived, measured, inferred, or operationally usable.

### Claim classes

Every claim should be tagged as one or more of these:

* **C0 — Framing claim**
  Defines scope, problem, or intent.
* **C1 — Descriptive claim**
  Says what exists, what was observed, or what prior work says.
* **C2 — Method claim**
  Says a method works, is appropriate, converges, is valid, or measures what it says it measures.
* **C3 — Derivational claim**
  Says X follows from Y by proof, derivation, or formal argument.
* **C4 — Empirical claim**
  Says results occurred in data, experiments, or simulations.
* **C5 — Causal/mechanistic claim**
  Says X causes, explains, or generates Y.
* **C6 — Generalization claim**
  Says a result holds beyond the directly shown case.
* **C7 — Novelty claim**
  Says something is new, first, unique, stronger, broader, or deeper.
* **C8 — Significance claim**
  Says the work matters, changes a field, or impacts domains.
* **C9 — Falsifiability claim**
  Says the work is testable, predictive, or has decisive gates.

A single sentence may contain multiple claims. Sneaky papers do this constantly.

---

# Second: define the difference between touched, stated, attempted, and supported

Your A–D group is excellent, but it needs sharper edges.

## A. Total claims touched

This is the **latent claim surface area**.

Count all claims the paper causes a reasonable reader to infer it is relying on, whether explicitly stated or not.

This includes:

* implied assumptions
* imported “standard results”
* hidden method validity claims
* unstated generalization jumps
* implied novelty claims
* implied domain transfer claims

This is the paper’s **true epistemic footprint**.

### Important rule

If a result only works because three “obvious” lemmas are assumed, those lemmas count in A even if never stated.

---

## B. Claims explicitly mentioned

These are claims the authors actually state in text, equations, captions, tables, appendices, or formal theorem/proposition labels.

This gives:

[
\text{Claim Explicitness Ratio} = \frac{B}{A}
]

Low score means the paper is doing epistemic smuggling.

---

## C. Claims with proof or support attempt

A claim counts here if the paper makes a **direct attempt** to justify it by one of:

* proof
* derivation
* experiment
* simulation
* citation used as actual support
* formal construction
* algorithmic validation
* explicit logical argument

Important: a citation dump without showing relevance is not support. That’s decorative bibliography cosplay.

[
\text{Support Attempt Ratio} = \frac{C}{A}
]

---

## D. Claims that hand-wave or import assumptions without derivation

This is your **epistemic debt count**.

A claim belongs in D if it depends on any of the following:

* “obvious”
* “standard”
* “well known”
* “it follows”
* “one can show”
* “by symmetry”
* “by usual arguments”
* imported theorem not adapted to the actual setting
* changed domain without re-deriving assumptions
* dropped boundary terms without justification
* hidden regularity assumptions
* undefined existence/uniqueness assumptions
* unstated measurement validity assumptions

[
\text{Handwave Rate} = \frac{D}{A}
]

This should be one of the main penalties.

This anti-handwave posture is very aligned with your own CF standards, which explicitly front-load claim inventories, decisive falsifiers, assumptions, and gates rather than tolerating “interesting but vague” argumentation.   

---

# Third: domain breadth vs domain relevance

Your E–F pair is strong because lots of papers flex across many domains to look profound. That trick needs a trapdoor.

## E. Domains touched

Count every distinct domain, subdomain, or technical field invoked by the paper.

Examples:

* differential geometry
* thermodynamics
* information geometry
* quantum measurement
* cosmology
* lattice numerics
* machine learning
* neuroscience

This is **breadth**.

---

## F. Domains directly used

Count only domains that are **structurally necessary** to the paper’s core argument.

A domain is directly used if removing it breaks:

* the main theorem
* the core method
* the main result
* the falsification program

[
\text{Domain Relevance Ratio} = \frac{F}{E}
]

Low score = domain peacocking.

---

# Fourth: falsifiability structure

This is where most papers get caught wearing a lab coat they did not earn.

Your G–J block should become a falsifiability ladder.

## G. Falsifiable claims

Of A, how many claims make contact with a world-state that could in principle prove them wrong?

Not all claims are falsifiable, but high-impact scientific claims should have a large falsifiable core.

[
\text{Falsifiability Coverage} = \frac{G}{A}
]

---

## H. Claims with falsification instructions

Of G, how many tell the reader **how** they could be tested?

This includes:

* metrics
* thresholds
* decisive experiments
* counterexample conditions
* rejection criteria
* prediction intervals
* protocols
* gate logic

[
\text{Testability Specification Ratio} = \frac{H}{G}
]

This matters a lot. “This is testable” without telling how is just another handwave in a lab coat.

Your own canon documents already push “claim inventory + decisive falsifiers + gates + CFN outputs” as required structure, which is exactly the kind of discipline this metric should reward.   

---

## I. Claims falsifiable immediately

Of G, how many can be challenged now with currently available data, math, experiments, or simulations?

[
\text{Immediate Falsifiability Ratio} = \frac{I}{G}
]

This is a huge credibility booster.

---

## J. Wait time to falsifiability

For claims in (G - I), estimate time to meaningful testability.

You want this binned, not vague:

* **J0**: immediate
* **J1**: days–weeks
* **J2**: months
* **J3**: 1–3 years
* **J4**: 3–10 years
* **J5**: >10 years / unknown / infrastructure missing

Then compute:

[
\text{Latency Penalty} = \sum_k p_k \cdot w_k
]

where (p_k) is the fraction in each latency bin and (w_k) is a penalty weight.

That prevents “testable in principle someday on Mars with a moon-sized detector” from pretending to be serious science.

---

# Fifth: novelty and significance

This part is easy to ruin with vanity, so it needs decomposition.

## K. Novel claims

Of A, how many claims are actually novel relative to prior literature?

Novel does **not** mean:

* new phrasing
* new notation
* remix of standard results
* “we combine A and B” with no new theorem, method, or result

A claim is novel only if it introduces at least one of:

* new theorem
* new proof strategy
* new measurable prediction
* new instrument or metric
* new algorithmic method
* new empirical finding
* new unification that reduces assumptions
* new falsification gate

[
\text{Novelty Coverage} = \frac{K}{A}
]

---

## L. Nature and depth of novelty

This should be qualitative plus scored.

### Novelty types

* **L1:** cosmetic / terminological
* **L2:** organizational / synthesis
* **L3:** methodological
* **L4:** formal / theorem-level
* **L5:** empirical / observational
* **L6:** predictive / falsifiable
* **L7:** foundational / paradigm-level

### Novelty depth score

For each novel claim, score 0–4 on:

* originality
* necessity
* irreducibility
* consequence

Then average.

This prevents “we renamed the sandwich” from scoring like an actual theorem.

---

## M. Significance / impact

This should be split into:

* **Internal significance**: importance within the target field
* **Cross-domain significance**: spillover to other fields
* **Operational significance**: changes what researchers can actually do
* **Foundational significance**: changes assumptions or theory structure

Each gets 0–4.

Then compute:
[
M = 0.35 M_{\text{internal}} + 0.20 M_{\text{cross}} + 0.20 M_{\text{operational}} + 0.25 M_{\text{foundational}}
]

This keeps “sounds huge” from overpowering “actually useful.”

---

# Sixth: consistency, coherence, and legibility

Your N should be expanded. This is where papers either read like clean steel or like a haunted swamp.

## N. Consistency and followability

Break it into submetrics:

### N1. Goal clarity

Can a careful reader state the paper’s primary goal in one sentence?

### N2. Scope discipline

Does the paper distinguish:

* what it proves
* what it conjectures
* what it assumes
* what it leaves open

### N3. Internal consistency

Any contradictions between abstract, intro, methods, results, or claims?

### N4. Dependency hygiene

Do later claims depend on unstated earlier assumptions?

### N5. Argument continuity

Can a reader follow the chain without jumping ravines?

### N6. Definition integrity

Are key terms defined once and used consistently?

### N7. Notation stability

Do symbols drift, mutate, or get reused sloppily?

### N8. Figure/table honesty

Do visuals support the argument instead of acting as decorative intimidation furniture?

Score each 0–4.

---

# Seventh: jargon scoring

You explicitly want to distinguish:

* unnecessary jargon
* tasteful necessary terminology
* master-level terminology with explanation

Excellent. That deserves its own system.

## Terminology Quality Index (TQI)

For all specialized terms:

### T1. Necessary terminology rate

Fraction of technical terms that are actually needed.

### T2. Defined-on-first-use rate

Fraction defined plainly at first appearance.

### T3. Compression value

Do terms shorten repeated structure efficiently, or just inflate prestige fog?

### T4. Explanation quality

Do definitions clarify function, not just swap one fancy word for another?

### T5. Jargon burden

How much of the paper’s readability cost comes from unnecessary terminology?

### T6. Terminology mastery

Does the paper use exact terms with elegance, restraint, and precision?

Then define:

[
\text{TQI} = 0.20T1 + 0.20T2 + 0.15T3 + 0.20T4 + 0.25T6 - 0.30T5
]

Scaled to 0–100.

### Hand-waviness vs terminology distinction

This is important:

* A paper can be **clear but wrong**
* A paper can be **jargon-light but hand-wavy**
* A paper can be **highly technical and still beautifully rigorous**

So jargon score must not be confused with rigor score.

Your reusable legibility prompt already encodes many of these principles: define unavoidable terms plainly, avoid dense jargon, prefer clarity over cleverness, and keep claims grounded. 

---

# Eighth: Bayesian metascores

Now the fun part. You asked for Bayesian metascores. Good. That means each paper gets both a point estimate and uncertainty.

## Why Bayesian here?

Because many review judgments are based on partial evidence. A reviewer should be able to say:

* “This looks rigorous, but confidence is medium because the claim extraction was hard.”
* “This seems hand-wavy with high confidence.”
* “Novelty score is low confidence because literature coverage was incomplete.”

That is sane science instead of fake omniscience.

## Suggested metascores

### 1. Extraction confidence

How confident are we that claims/domains/assumptions were counted correctly?

### 2. Support confidence

How confident are we that “support attempt” really qualifies as support?

### 3. Novelty confidence

How complete was prior-art comparison?

### 4. Falsifiability confidence

How confident are we that a claim is genuinely testable and not only rhetorically testable?

### 5. Composite confidence

Overall confidence in the final BASS score.

---

## Simple Bayesian model

For each proportion-like metric, use a Beta posterior.

Example for explicitness:

* prior: (\text{Beta}(\alpha_0,\beta_0))
* observed: (B) explicit out of (A) total

Posterior:

[
\theta_{\text{explicit}} \sim \text{Beta}(\alpha_0 + B,; \beta_0 + A - B)
]

Posterior mean:

[
\mathbb{E}[\theta] = \frac{\alpha_0 + B}{\alpha_0 + \beta_0 + A}
]

Do this for:

* explicitness
* support attempt
* handwave complement
* falsifiability
* specification quality
* immediate falsifiability
* novelty coverage
* domain relevance

Use weak priors like Beta(1,1) or calibrated priors from your own reviewed corpus later.

---

# Ninth: the actual composite score

Here’s the clean version.

## Core normalized subscores

Define:

* (S_{\text{exp}} = B/A)
* (S_{\text{sup}} = C/A)
* (S_{\text{antiHW}} = 1 - D/A)
* (S_{\text{dom}} = F/E)
* (S_{\text{fals}} = G/A)
* (S_{\text{test}} = H/G)
* (S_{\text{imm}} = I/G)
* (S_{\text{nov}} = K/A)
* (S_{\text{coh}} = N/100) or average of N-subscores
* (S_{\text{term}} = TQI/100)
* (S_{\text{impact}} = M/100)

Then define a latency modifier from J:

[
S_{\text{lat}} = 1 - \text{LatencyPenalty}
]

clamped to [0,1].

---

## Recommended BASS composite

[
\text{BASS} =
100 \cdot
\Big(
0.14S_{\text{sup}} +
0.13S_{\text{antiHW}} +
0.11S_{\text{fals}} +
0.10S_{\text{test}} +
0.08S_{\text{imm}} +
0.10S_{\text{coh}} +
0.08S_{\text{term}} +
0.08S_{\text{nov}} +
0.07S_{\text{impact}} +
0.06S_{\text{exp}} +
0.05S_{\text{dom}}
\Big)\cdot S_{\text{lat}}^{0.35}
]

### Why this weighting?

Because:

* actual support and anti-handwave discipline matter most
* falsifiability matters a lot
* clarity/coherence matter substantially
* novelty matters, but less than rigor
* impact matters, but should not let a speculative moon-beam cannon outrank solid work
* explicitness and domain hygiene matter, but are secondary

---

# Tenth: verdict bands

## BASS interpretation

* **90–100**: exceptional rigor, unusually auditable
* **80–89**: strong, credible, high substance
* **70–79**: solid but with notable weaknesses
* **60–69**: mixed; useful but structurally unreliable in places
* **45–59**: weak rigor / serious handwave contamination
* **<45**: credibility hazard / prestige theater / under-supported

---

# Eleventh: add the things your current list is missing

Here are the most important additions.

## O. Assumption transparency

How many assumptions are:

* explicit
* justified
* scoped
* necessary

This is distinct from D because some assumptions are fine if honestly stated.

---

## P. Dependency traceability

Can each major claim be traced backward to:

* assumptions
* definitions
* prior lemmas
* data
* cited results

This is basically the paper’s dependency graph cleanliness.

---

## Q. Evidence-role integrity

For every citation, figure, or theorem, is its role clear?

Possible roles:

* background
* support
* contrast
* dependency
* replication
* external validation

Many papers cheat by citing background as if it were support.

---

## R. Boundary-condition honesty

Does the paper clearly state where its argument may fail?

This matters a ton in mathematical physics and cross-domain papers. Your own CF material explicitly calls out boundary/completion issues, noncompactness, and the need to mark proven vs conjectured vs conditioned statements.  

---

## S. Reproducibility / auditability

Can another competent person:

* rerun
* re-derive
* check gates
* inspect artifacts
* reproduce key conclusions

Your results standards emphasize provenance, gates, thresholds, artifact paths, and reproducibility hooks. That should be rewarded directly by the standard.   

---

## T. Scope-to-evidence ratio

How big are the claims relative to the evidence actually shown?

This catches papers that prove a pebble and announce a mountain.

[
T = \frac{\text{evidence-backed scope}}{\text{claimed scope}}
]

This is a savage and useful metric.

---

# Twelfth: operational review workflow

To make this practical, reviewers should follow a fixed pass order.

## Review pass order

### Pass 1 — Claim extraction

Build list A.

### Pass 2 — Explicitness and support

Mark B, C, D.

### Pass 3 — Domain map

Mark E, F.

### Pass 4 — Falsifiability map

Mark G, H, I, J.

### Pass 5 — Novelty and significance

Mark K, L, M.

### Pass 6 — Coherence and terminology

Mark N + TQI.

### Pass 7 — Bayesian confidence

Assign confidence by evidence completeness.

### Pass 8 — Composite output

Produce:

* BASS score
* confidence interval
* weakness profile
* brief verdict

---

# Thirteenth: a compact output template

## CRAFT Review Output

**Paper:**
**Reviewer:**
**Version/date:**

### 1. Core counts

* A total claims touched:
* B explicit claims:
* C supported/proven-attempt claims:
* D handwaved/imported claims:
* E domains touched:
* F domains directly used:
* G falsifiable claims:
* H falsification instructions present:
* I immediately falsifiable:
* J latency profile:
* K novel claims:

### 2. Normalized ratios

* Explicitness:
* Support attempt:
* Anti-handwave:
* Domain relevance:
* Falsifiability coverage:
* Test specification:
* Immediate falsifiability:
* Novelty coverage:
* Coherence:
* Terminology quality:
* Significance:

### 3. Bayesian metascores

* Extraction confidence:
* Novelty confidence:
* Falsifiability confidence:
* Composite confidence:

### 4. Composite

* **BASS score:**
* **Credibility band:**
* **Confidence interval:**

### 5. Diagnostic verdict

* strongest feature:
* weakest feature:
* biggest hidden assumption:
* fastest falsifier:
* jargon verdict:
* recommendation:

---

# Fourteenth: anti-gaming rules

A standard like this will get gamed unless you explicitly stop the nonsense.

## Anti-gaming constraints

### Rule 1

More claims do not help unless support grows proportionally.

### Rule 2

Fancy terminology with poor definitions lowers score.

### Rule 3

Novelty claims are penalized if unsupported by prior-art comparison.

### Rule 4

Cross-domain breadth is penalized if direct relevance is low.

### Rule 5

Claims marked “future work” do not count as supported.

### Rule 6

Citations do not count as proof unless their relevance is explicitly integrated.

### Rule 7

Conjectures are fine if clearly labeled. Hidden conjectures are not fine.

### Rule 8

A paper may score well while being wrong, if it is rigorous, transparent, and falsifiable. That is a feature, not a bug. Science is allowed to be wrong; it is not allowed to be slippery.

---

# Fifteenth: the deeper distinction your standard should make

This is the really important philosophical split.

Your framework should distinguish **three failure modes** that are often lazily lumped together:

## 1. Honest incompleteness

The paper says:

* here is what is proven
* here is what is conjectured
* here is what would falsify it

This can still score high.

## 2. Decorative rigor

The paper looks formal, but the logic chain is full of hidden jumps.

This should score badly.

## 3. Prestige fog

The paper uses vocabulary, citations, and breadth as camouflage for low support density.

This should get absolutely bonked by D, TQI burden, and scope-to-evidence ratio.

---

# Sixteenth: recommended extra derived metrics

These will make the system sharper.

## Support Density

[
\text{Support Density} = \frac{C}{B}
]
Of the explicit claims, how many are actually supported?

## Hidden Burden Index

[
\text{HBI} = \frac{A-B}{A}
]
How much of the paper’s claim load is implicit?

## Epistemic Debt Index

[
\text{EDI} = \frac{D}{C + 1}
]
How much unsupported debt exists relative to actual support effort?

## Scope Inflation Index

[
\text{SII} = \frac{A}{C+1}
]
How much claim surface is being projected per support attempt?

## Falsification Readiness

[
\text{FR} = \frac{H + I}{2G}
]
How close are falsifiable claims to actual testing?

## Terminological Efficiency

[
\text{TE} = \frac{\text{necessary defined terms}}{\text{all technical terms}}
]

---

# Seventeenth: direct improvements to your original A–N wording

Here is a cleaner version of your items.

## Revised core questions

**A. Total claim surface**
How many distinct claims does the paper rely on, whether stated explicitly or only implied?

**B. Claim explicitness**
How many of the claims in A are clearly stated?

**C. Support attempt coverage**
How many of the claims in A receive a direct attempt at proof, derivation, measurement, validation, or argument?

**D. Handwave/import count**
How many claims in A rely on imported assumptions, appeals to obviousness, standard practice, omitted derivations, or unsupported transitions?

**E. Domain breadth**
How many domains, subjects, or subdomains are touched?

**F. Domain necessity**
How many of those domains are directly necessary to the paper’s core argument or result?

**G. Falsifiability coverage**
How many claims in A are falsifiable in principle?

**H. Falsification specification**
How many falsifiable claims include explicit instructions, requirements, criteria, or metrics for testing them?

**I. Immediate falsifiability**
How many falsifiable claims can be tested now with currently available tools, data, or mathematics?

**J. Falsifiability latency**
For falsifiable claims not immediately testable, what is the estimated wait time until serious testing becomes possible?

**K. Novel claim count**
How many claims in A are genuinely novel relative to prior art?

**L. Novelty character and depth**
What kind of novelty is present, and how deep or consequential is it?

**M. Significance / impact**
If correct, how much would this work matter within its target domain and beyond?

**N. Coherence / followability**
How internally consistent, structurally clear, and readable is the paper? Is the goal explicit and maintained?

And add:

**O. Assumption transparency**
How clearly are assumptions stated, scoped, and justified?

**P. Reproducibility / auditability**
Can the main argument or result be independently checked, rerun, or reconstructed?

**Q. Terminology quality**
Does the paper use technical language with necessary precision and sufficient explanation, or does it use jargon as camouflage?

---

# Final shape

The cleanest system is:

* **CRAFT dimensions** = A through Q
* **derived ratios** = explicitness, support density, anti-handwave, domain necessity, falsification readiness, novelty coverage, terminology efficiency
* **Bayesian posterior confidence** on each
* **BASS composite score** as the final normalized grade

That gives you something that can actually become a house standard, a reviewer tool, a scoring spreadsheet, or a paper-audit engine.

There’s real steel in this. It rhymes with the strongest parts of your own canon standards: front-loaded claims, assumptions, gates, provenance, no hidden burden, and honest separation of proven vs conjectured vs testable.   

I can turn this into a polished **formal specification document** next, with tables, formulas, reviewer instructions, and a one-page scoring sheet.

